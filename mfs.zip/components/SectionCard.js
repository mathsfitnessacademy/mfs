import styles from '../styles/SectionCard.module.css'
import Image from 'next/image'
import Link from 'next/link'

function SectionCard(){

}

export default SectionCard