function Success(){
    return <h3>Successfully submitted the button.</h3>
}

export default Success