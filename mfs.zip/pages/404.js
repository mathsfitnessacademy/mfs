function PageNotFound() {
    return <h1>This page not found 404</h1>
}

export default PageNotFound