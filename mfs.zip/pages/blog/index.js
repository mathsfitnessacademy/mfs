
function Blogs(){7
    return (
        <>
            <h2>Blog 1</h2>
            <h2>Blog 2</h2>
            <h2>Blog 3</h2>
        </>
    )
}

export default Blogs