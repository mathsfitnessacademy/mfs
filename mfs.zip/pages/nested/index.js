function Nested(){
    return <h1>Nested Page</h1>
}

export default Nested