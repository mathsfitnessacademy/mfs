"use strict";
(() => {
var exports = {};
exports.id = 70;
exports.ids = [70];
exports.modules = {

/***/ 2139:
/***/ ((module) => {

module.exports = require("@sendgrid/mail");

/***/ }),

/***/ 218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const mail = __webpack_require__(2139);
mail.setApiKey(process.env.SENDGRID_API_KEY);
const mails = (req, res)=>{
    const body = JSON.parse(req.body);
    const message = `
        Name: ${body.fname}\s${body.lname}\r\n
        Email: ${body.mail}\r\n
        Subject: ${body.mfs}\r\n
        Message: ${body.message}
    `;
    const data = {
        to: 'uaj.hisham@gmail.com',
        from: 'admin@mathsfitnessacademy.com',
        subject: 'Message from user',
        text: message,
        html: message.replace(/\r\n/g, '<br>')
    };
    console.log(data);
    mail.send(data);
    res.status(200).json({
        status: 'Ok'
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mails);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(218));
module.exports = __webpack_exports__;

})();