(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 9180:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar": "Layout_navbar__OuN2_",
	"active": "Layout_active__VNpgM",
	"navlogo": "Layout_navlogo__IDZGD",
	"menucontainer": "Layout_menucontainer__IvuKu",
	"navmenu": "Layout_navmenu__upBn0",
	"navitem": "Layout_navitem__5wPVR",
	"navlink": "Layout_navlink__Cu2tv",
	"selectednav": "Layout_selectednav__LqYmI",
	"navCol": "Layout_navCol__j1tBK",
	"hamburger": "Layout_hamburger__JbfQq",
	"bar": "Layout_bar__u8wjH",
	"btn": "Layout_btn__MUNIl",
	"bluebtn": "Layout_bluebtn__4oblx",
	"roundBtns": "Layout_roundBtns__KiyfZ",
	"roundBtn1": "Layout_roundBtn1__KL_9X",
	"roundBtn2": "Layout_roundBtn2__UxcgK",
	"footbtn": "Layout_footbtn__P_Bu8",
	"footer": "Layout_footer__mj7GQ",
	"contact_footer": "Layout_contact_footer__OJzQ5",
	"icon": "Layout_icon__Tz3hO",
	"iconImage1": "Layout_iconImage1__3MjJ8",
	"iconImage2": "Layout_iconImage2__IR90e",
	"caption": "Layout_caption__68VWA",
	"contact": "Layout_contact__3sqNL",
	"footnav": "Layout_footnav__JnM6j",
	"footitems": "Layout_footitems__qY1Ox",
	"footnavlink": "Layout_footnavlink__Zipff",
	"social_icons": "Layout_social_icons__B1s1W",
	"socialIcon": "Layout_socialIcon__92Z0t",
	"copyright": "Layout_copyright__tUUWc"
};


/***/ }),

/***/ 8290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./styles/Layout.module.css
var Layout_module = __webpack_require__(9180);
var Layout_module_default = /*#__PURE__*/__webpack_require__.n(Layout_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/Header.js






function Header() {
    const { 0: isOpen , 1: setIsOpen  } = (0,external_react_.useState)(false);
    const openmenu = ()=>setIsOpen(!isOpen)
    ;
    const router = (0,router_.useRouter)();
    const { 0: navbar , 1: setNavbar  } = (0,external_react_.useState)(false);
    const changeBackground = ()=>{
        if (window.scrollY >= screen.height - 200) {
            setNavbar(true);
        } else {
            setNavbar(false);
        }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener('scroll', changeBackground);
        return ()=>window.removeEventListener('scroll', changeBackground)
        ;
    }, []);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: navbar ? (Layout_module_default()).navbar + " " + (Layout_module_default()).active : (Layout_module_default()).navbar,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Layout_module_default()).logocontainer,
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: "/",
                    passHref: true,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (Layout_module_default()).navlogo,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                            src: "/Logo.svg",
                            width: 180,
                            height: 50,
                            alt: ""
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Layout_module_default()).menucontainer,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Layout_module_default()).navCol,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: isOpen === false ? (Layout_module_default()).navmenu : (Layout_module_default()).navmenu + ' ' + (Layout_module_default()).active,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: (Layout_module_default()).navitem,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/",
                                        passHref: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: router.pathname == "/" ? (Layout_module_default()).navlink + " " + (Layout_module_default()).selectednav : (Layout_module_default()).navlink,
                                            children: "Home"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: (Layout_module_default()).navitem,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/about",
                                        passHref: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: router.pathname == "/about" ? (Layout_module_default()).navlink + " " + (Layout_module_default()).selectednav : (Layout_module_default()).navlink,
                                            children: "About"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: (Layout_module_default()).navitem,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/course",
                                        passHref: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: router.pathname == "/course" ? (Layout_module_default()).navlink + " " + (Layout_module_default()).selectednav : (Layout_module_default()).navlink,
                                            children: "Courses"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: (Layout_module_default()).navitem,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/tool",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: router.pathname == "/tool" ? (Layout_module_default()).navlink + " " + (Layout_module_default()).selectednav : (Layout_module_default()).navlink,
                                            children: "Our Tool"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: (Layout_module_default()).navitem,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                        href: "/contact",
                                        passHref: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: router.pathname == "/contact" ? (Layout_module_default()).navlink + " " + (Layout_module_default()).selectednav : (Layout_module_default()).navlink,
                                            children: "Contact"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (Layout_module_default()).roundBtns,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "https://students.mathsfitnessacademy.com/home",
                                            passHref: true,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: (Layout_module_default()).roundBtn1,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                    src: "/register_login.png",
                                                    width: 50,
                                                    height: 50,
                                                    alt: ""
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/contact",
                                            passHref: true,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: (Layout_module_default()).roundBtn2,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                    src: "/contactus.png",
                                                    width: 50,
                                                    height: 50,
                                                    alt: ""
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Layout_module_default()).navCol,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "https://students.mathsfitnessacademy.com/home",
                                passHref: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: (Layout_module_default()).bluebtn,
                                    children: "Register/Login"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/contact",
                                passHref: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: (Layout_module_default()).btn,
                                    children: "Call us: +91 9544138443"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        className: isOpen === false ? (Layout_module_default()).hamburger : (Layout_module_default()).hamburger + ' ' + (Layout_module_default()).active,
                        onClick: openmenu,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (Layout_module_default()).bar
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (Layout_module_default()).bar
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (Layout_module_default()).bar
                            })
                        ]
                    })
                ]
            })
        ]
    }));
}
/* harmony default export */ const components_Header = (Header);

;// CONCATENATED MODULE: ./components/Footer.js




function Footer() {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Layout_module_default()).footer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Layout_module_default()).contact_footer,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Layout_module_default()).icon,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Layout_module_default()).iconImage1,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    className: (Layout_module_default()).icon1,
                                    src: "/mobile.svg",
                                    width: 22,
                                    height: 40,
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Layout_module_default()).footTexts,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: (Layout_module_default()).caption,
                                        children: "Call"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: (Layout_module_default()).contact,
                                        children: "9895XXXXXX"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Layout_module_default()).icon,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Layout_module_default()).iconImage2,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    className: (Layout_module_default()).icon2,
                                    src: "/mail.svg",
                                    width: 41,
                                    height: 29,
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Layout_module_default()).footTexts,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: (Layout_module_default()).caption,
                                        children: "Mail"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: (Layout_module_default()).contact,
                                        children: "info@fitnessacademy\xb7com"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: "/contact",
                        passHref: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: (Layout_module_default()).footbtn,
                            children: "BOOK A FREE DEMO"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    borderTop: "2px solid #eee ",
                    marginLeft: 60,
                    marginRight: 60
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Layout_module_default()).footnav,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: (Layout_module_default()).footitems,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/",
                                    passHref: true,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Layout_module_default()).footnavlink,
                                        children: "Home"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/about",
                                    passHref: true,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Layout_module_default()).footnavlink,
                                        children: "About"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/course",
                                    passHref: true,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Layout_module_default()).footnavlink,
                                        children: "Courses"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/tool",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Layout_module_default()).footnavlink,
                                        children: "Our Tool"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/contact",
                                    passHref: true,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: (Layout_module_default()).footnavlink,
                                        children: "Contact"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Layout_module_default()).social_icons,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                passHref: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: (Layout_module_default()).iconLink,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Layout_module_default()).socialIcon,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            src: "/fb.svg",
                                            width: 35,
                                            height: 35,
                                            alt: ""
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                passHref: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: (Layout_module_default()).iconLink,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Layout_module_default()).socialIcon,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            src: "/insta.svg",
                                            width: 36,
                                            height: 35,
                                            alt: ""
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                passHref: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: (Layout_module_default()).iconLink,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Layout_module_default()).socialIcon,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            src: "/twitter.svg",
                                            width: 35,
                                            height: 35,
                                            alt: ""
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                passHref: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: (Layout_module_default()).iconLink,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Layout_module_default()).socialIcon,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                            src: "/youtube.svg",
                                            width: 35,
                                            height: 35,
                                            alt: ""
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    borderTop: "2px solid #eee ",
                    marginLeft: 60,
                    marginRight: 60
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Layout_module_default()).copyright,
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "Copyright \xa9 2022 Maths Fitness Academy. All Rights Reserved. Privacy Statement , Terms & Conditions"
                })
            })
        ]
    }));
}
/* harmony default export */ const components_Footer = (Footer);

;// CONCATENATED MODULE: ./components/Layout.js



function Layout({ children  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_Header, {}),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
        ]
    }));
}
/* harmony default export */ const components_Layout = (Layout);

;// CONCATENATED MODULE: ./pages/_app.js



function MyApp({ Component , pageProps  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Layout, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        })
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,664], () => (__webpack_exec__(8290)));
module.exports = __webpack_exports__;

})();