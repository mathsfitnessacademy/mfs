exports.id = 816;
exports.ids = [816];
exports.modules = {

/***/ 7889:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Start_container__iM_PV",
	"header": "Start_header__SPQu0",
	"arrow1": "Start_arrow1__KkLlh",
	"title": "Start_title__PSWbK",
	"description": "Start_description__ZyDIG",
	"flow": "Start_flow__uvzir",
	"startText": "Start_startText__7RTHb",
	"startarrow": "Start_startarrow__RciYt",
	"arrow": "Start_arrow__Rdfb5",
	"steps": "Start_steps__qmzvn",
	"step": "Start_step__ub3G7",
	"headText": "Start_headText__kfxn6",
	"head1": "Start_head1__m4NPE",
	"head2": "Start_head2__p1nj9",
	"steps1": "Start_steps1__xfCPw",
	"finishText": "Start_finishText__GNfAW",
	"finisharrow": "Start_finisharrow__lwtcX",
	"redcolor": "Start_redcolor__xmARQ"
};


/***/ }),

/***/ 4816:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Start)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/Start.module.css
var Start_module = __webpack_require__(7889);
var Start_module_default = /*#__PURE__*/__webpack_require__.n(Start_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/TextBox.js



const TextBox = (props)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (Start_module_default()).step,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (Start_module_default()).headText,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: (Start_module_default()).head1,
                    children: props.first
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: (Start_module_default()).head2,
                    children: props.second
                })
            ]
        })
    })
;
/* harmony default export */ const components_TextBox = (TextBox);

;// CONCATENATED MODULE: ./components/Start.js



function Start() {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Start_module_default()).container,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Start_module_default()).header,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: (Start_module_default()).title,
                        children: "How to start the course"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (Start_module_default()).description,
                        children: "The course begins with an assessment, which serves as a benchmark to gauge a student's skill level after registering. After learning new techniques, students master them through practice."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Start_module_default()).flow,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: (Start_module_default()).startText,
                        children: "Start"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Start_module_default()).startarrow
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Start_module_default()).steps,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(components_TextBox, {
                                first: "Registration",
                                second: "Creating Student Profile"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Start_module_default()).arrow
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_TextBox, {
                                first: "Maths Fitness Benchmark Test",
                                second: "Know Your Current Preformance Level"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Start_module_default()).arrow
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_TextBox, {
                                first: "Weekly Class",
                                second: "Learn New Techniques"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Start_module_default()).arrow
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Start_module_default()).flow,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Start_module_default()).steps1,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(components_TextBox, {
                                first: "Daily Practice",
                                second: "practice makes it permanent"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Start_module_default()).arrow
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_TextBox, {
                                first: "Final Assessment",
                                second: "measure your progress"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Start_module_default()).arrow
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_TextBox, {
                                first: "Evaluation and certification",
                                second: "performance report and E-certificate issued"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Start_module_default()).finisharrow
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: (Start_module_default()).finishText,
                        children: "Finish"
                    })
                ]
            })
        ]
    }));
}
/* harmony default export */ const components_Start = (Start);


/***/ })

};
;